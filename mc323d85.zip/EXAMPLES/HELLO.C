/*
 * Simple 'hello' program.
 */
#include <8085io.h>

main()
{
	putstr("Hello World\n");
}
